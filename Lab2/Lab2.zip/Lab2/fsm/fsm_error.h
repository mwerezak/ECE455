#ifndef FSM_ERROR_H
#define FSM_ERROR_H

void FSM_RaiseError(unsigned char* error_message);

#endif
