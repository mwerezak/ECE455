#ifndef LED_H
#define LED_H

void LED_Init(void);
void LED_On(int led);
void LED_Clear(int led);
void LED_Set(int led, int set);

#endif
