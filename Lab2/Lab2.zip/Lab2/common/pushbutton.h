#ifndef PUSHBUTTON_H
#define PUSHBUTTON_H

//*** Pushbutton

void Pushbutton_Init(void);
void Pushbutton_ClearInterrupt(void);
int Pushbutton_ReadValue(void);

#endif
